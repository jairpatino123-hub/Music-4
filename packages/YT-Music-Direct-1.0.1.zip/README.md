# Synthetiq YouTube Music Direct 1.0.1

Staging connector for Synthetiq Music.

## What it does
- Searches YouTube Music through the WEB_REMIX InnerTube endpoint.
- Returns music-track metadata, artwork, duration, and YouTube Music IDs.
- Provides home discovery sections.
- Returns the canonical YouTube Music player route for a selected track.

## Playback limitation
YouTube Music search/metadata and raw media playback are separate operations. This connector does **not** scrape, decrypt, or fabricate a reusable raw audio URL. The playback result is the canonical YouTube Music route, and the host app decides whether that route is supported by its native playback policy.

## Configuration
No credential is embedded. An optional `youtubeMusicApiKey` may be injected by the Synthetiq Music runtime.

## Release track
`staging`

This package is intended for testing and must not be represented as verified full-catalogue raw-audio playback.
